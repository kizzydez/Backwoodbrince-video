import 'dart:async';
import 'package:myapp/src/teta_files/imports.dart';
import 'package:myapp/constants.dart' as constantz;
import 'package:myapp/auth/auth_state.dart';

import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:bouncing_widget/bouncing_widget.dart';

class PageEntryPoint extends StatefulWidget {
  const PageEntryPoint({
    Key? key,
  }) : super(key: key);

  @override
  _StateEntryPoint createState() => _StateEntryPoint();
}

class _StateEntryPoint extends State<PageEntryPoint> {
  String state1 = '0';

  var datasets = <String, dynamic>{};
  int index = 0;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    TetaCMS.instance.analytics.insertEvent(
      TetaAnalyticsType.usage,
      'App usage: view page',
      <String, dynamic>{
        'name': "EntryPoint",
      },
      isUserIdPreferableIfExists: true,
    );

    unawaited(
      Future.delayed(
        Duration.zero,
        () async {},
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomInset: true,
      backgroundColor: const Color(0xFF000000),
      body: Stack(
        children: [
          Container(
            width: double.maxFinite,
            decoration: BoxDecoration(
              color: context.watch<ThemeCubit>().state
                  ? TetaThemes.lightTheme['Background / Primary'] as Color
                  : TetaThemes.darkTheme['Background / Primary'] as Color,
            ),
            child: NotificationListener<ScrollEndNotification>(
              onNotification: (final scrollEnd) {
                final metrics = scrollEnd.metrics;
                if (metrics.atEdge) {
                  final isTop = metrics.pixels == 0;
                  if (isTop) {
                  } else {}
                }
                return true;
              },
              child: ListView(
                reverse: false,
                primary: true,
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  SafeArea(
                    left: false,
                    top: true,
                    right: false,
                    bottom: false,
                    child: AnimationConfiguration.staggeredList(
                      position: 0,
                      duration: Duration(
                        milliseconds: 3000,
                      ),
                      child: FadeInAnimation(
                        child: SizedBox(
                          width: double.maxFinite,
                          height: 40.h,
                          child: Padding(
                            padding: const EdgeInsets.only(
                              top: 100,
                            ),
                            child: Image.network(
                              r'''https://ujwtjucjmyzlktgfrara.supabase.co/storage/v1/object/public/bookimages/Images/20221021_211054_0000-removebg-preview.png''',
                              width: double.maxFinite,
                              height: 150,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: double.maxFinite,
                    height: 8,
                    child: Text(r'''''',
                        style: GoogleFonts.poppins(
                          textStyle: TextStyle(
                            color: Color(0xFFFFFFFF).withOpacity(1),
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            fontStyle: FontStyle.normal,
                            decoration: TextDecoration.none,
                          ),
                        ),
                        textAlign: TextAlign.left,
                        textDirection: TextDirection.ltr,
                        maxLines: 1),
                  ),
                  BouncingWidget(
                    onPressed: () async {
                      await Navigator.push<void>(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PagePageA2(),
                        ),
                      );
                    },
                    duration: const Duration(milliseconds: 3000),
                    scaleFactor: 1.5,
                    child: SizedBox(
                      width: double.maxFinite,
                      height: 150,
                      child: Column(
                        children: [
                          Text(r'''Video Player''',
                              style: GoogleFonts.poppins(
                                textStyle: TextStyle(
                                  color: context.watch<ThemeCubit>().state
                                      ? TetaThemes.lightTheme['Text / Primary']
                                          as Color
                                      : TetaThemes.darkTheme['Text / Primary']
                                          as Color,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 25,
                                  fontStyle: FontStyle.normal,
                                  decoration: TextDecoration.none,
                                ),
                              ),
                              textAlign: TextAlign.left,
                              textDirection: TextDirection.ltr,
                              maxLines: 1),
                          Text(
                              r'''Keep watching, movies are beautiful thing. There is so much to watch''',
                              style: GoogleFonts.poppins(
                                textStyle: TextStyle(
                                  color: context.watch<ThemeCubit>().state
                                      ? TetaThemes.lightTheme['Text / Primary']
                                          as Color
                                      : TetaThemes.darkTheme['Text / Primary']
                                          as Color,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 16,
                                  fontStyle: FontStyle.normal,
                                  decoration: TextDecoration.none,
                                ),
                              ),
                              textAlign: TextAlign.center,
                              textDirection: TextDirection.ltr,
                              maxLines: 3),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
