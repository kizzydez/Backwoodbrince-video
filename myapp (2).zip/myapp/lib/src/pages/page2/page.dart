import 'dart:async';
import 'package:myapp/src/teta_files/imports.dart';
import 'package:myapp/constants.dart' as constantz;
import 'package:myapp/auth/auth_state.dart';

import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:bouncing_widget/bouncing_widget.dart';
import 'package:webviewx/webviewx.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'dart:io';
import 'package:url_launcher/url_launcher_string.dart';

class PagePageA2 extends StatefulWidget {
  const PagePageA2({
    Key? key,
  }) : super(key: key);

  @override
  _StatePageA2 createState() => _StatePageA2();
}

class _StatePageA2 extends State<PagePageA2> {
  WebViewXController? webbiii = null;

  var datasets = <String, dynamic>{};
  int index = 0;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    TetaCMS.instance.analytics.insertEvent(
      TetaAnalyticsType.usage,
      'App usage: view page',
      <String, dynamic>{
        'name': "PageA2",
      },
      isUserIdPreferableIfExists: true,
    );

    unawaited(
      Future.delayed(
        Duration.zero,
        () async {},
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomInset: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(120),
        child: Container(
          width: double.maxFinite,
          height: 10.h,
          decoration: BoxDecoration(
            color: Color(0xFF000000).withOpacity(1),
          ),
          child: FutureBuilder<BannerAd>(
            future: Future.delayed(Duration(milliseconds: 0), () async {
              final ad = BannerAd(
                request: const AdRequest(),
                adUnitId: UniversalPlatform.isIOS
                    ? '''ca-app-pub-1653840116883774/4179327358'''
                    : '''ca-app-pub-1653840116883774/8006907635''',
                listener: const BannerAdListener(),
                size: AdSize.fluid,
              );
              await ad.load();
              return ad;
            }),
            builder: (context, ad) {
              if (ad.data == null) {
                return Container();
              }
              return AdWidget(
                ad: ad.data!,
              );
            },
          ),
        ),
      ),
      drawer: Drawer(
        child: Container(
          width: double.maxFinite,
          decoration: BoxDecoration(
            color: Color(0xFF000000).withOpacity(1),
          ),
          child: SafeArea(
            left: false,
            top: false,
            right: false,
            bottom: false,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    top: 3,
                  ),
                  child: GestureDetector(
                    onTap: () async {
                      await BlocProvider.of<ThemeCubit>(context).changeVal();
                    },
                    child: Container(
                        width: double.maxFinite,
                        height: 48,
                        decoration: BoxDecoration(
                          color: context.watch<ThemeCubit>().state
                              ? TetaThemes.lightTheme['Text / Primary'] as Color
                              : TetaThemes.darkTheme['Text / Primary'] as Color,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30),
                            topRight: Radius.circular(30),
                            bottomRight: Radius.circular(30),
                            bottomLeft: Radius.circular(30),
                          ),
                          border: null,
                        ),
                        child: Center(
                          child: Text(
                            '''Theme''',
                            style: GoogleFonts.poppins(
                              textStyle: TextStyle(
                                color: context.watch<ThemeCubit>().state
                                    ? TetaThemes
                                            .lightTheme['Background / Primary']
                                        as Color
                                    : TetaThemes
                                            .darkTheme['Background / Primary']
                                        as Color,
                                fontWeight: FontWeight.w400,
                                fontSize: 16,
                                fontStyle: FontStyle.normal,
                                decoration: TextDecoration.none,
                              ),
                            ),
                            textAlign: TextAlign.center,
                            textDirection: TextDirection.ltr,
                          ),
                        )),
                  ),
                ),
                GestureDetector(
                  onTap: () async {
                    if (await canLaunchUrlString(
                        '''https://backwood-brince.gitbook.io/backwood-brince/''')) {
                      await launchUrlString(
                        '''https://backwood-brince.gitbook.io/backwood-brince/''',
                        mode: LaunchMode.inAppWebView,
                      );
                    }
                  },
                  child: Container(
                      width: double.maxFinite,
                      height: 48,
                      decoration: BoxDecoration(
                        color: context.watch<ThemeCubit>().state
                            ? TetaThemes.lightTheme['Text / Primary'] as Color
                            : TetaThemes.darkTheme['Text / Primary'] as Color,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30),
                          bottomRight: Radius.circular(30),
                          bottomLeft: Radius.circular(30),
                        ),
                        border: null,
                      ),
                      child: Center(
                        child: Text(
                          '''Whitepaper''',
                          style: GoogleFonts.poppins(
                            textStyle: TextStyle(
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes
                                          .lightTheme['Background / Primary']
                                      as Color
                                  : TetaThemes.darkTheme['Background / Primary']
                                      as Color,
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                              fontStyle: FontStyle.normal,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          textAlign: TextAlign.center,
                          textDirection: TextDirection.ltr,
                        ),
                      )),
                ),
                GestureDetector(
                  onTap: () async {
                    if (await canLaunchUrlString(
                        '''https://discord.gg/3Vn2FcNu''')) {
                      await launchUrlString(
                        '''https://discord.gg/3Vn2FcNu''',
                        mode: LaunchMode.inAppWebView,
                      );
                    }
                  },
                  child: Container(
                      width: double.maxFinite,
                      height: 48,
                      decoration: BoxDecoration(
                        color: context.watch<ThemeCubit>().state
                            ? TetaThemes.lightTheme['Text / Primary'] as Color
                            : TetaThemes.darkTheme['Text / Primary'] as Color,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30),
                          bottomRight: Radius.circular(30),
                          bottomLeft: Radius.circular(30),
                        ),
                        border: null,
                      ),
                      child: Center(
                        child: Text(
                          '''join Discord''',
                          style: GoogleFonts.poppins(
                            textStyle: TextStyle(
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes
                                          .lightTheme['Background / Primary']
                                      as Color
                                  : TetaThemes.darkTheme['Background / Primary']
                                      as Color,
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                              fontStyle: FontStyle.normal,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          textAlign: TextAlign.center,
                          textDirection: TextDirection.ltr,
                        ),
                      )),
                ),
                GestureDetector(
                  onTap: () async {
                    await Navigator.push<void>(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PageWhyads(),
                      ),
                    );
                  },
                  child: Container(
                      width: double.maxFinite,
                      height: 48,
                      decoration: BoxDecoration(
                        color: context.watch<ThemeCubit>().state
                            ? TetaThemes.lightTheme['Text / Primary'] as Color
                            : TetaThemes.darkTheme['Text / Primary'] as Color,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30),
                          bottomRight: Radius.circular(30),
                          bottomLeft: Radius.circular(30),
                        ),
                        border: null,
                      ),
                      child: Center(
                        child: Text(
                          '''Why Ads''',
                          style: GoogleFonts.poppins(
                            textStyle: TextStyle(
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes
                                          .lightTheme['Background / Primary']
                                      as Color
                                  : TetaThemes.darkTheme['Background / Primary']
                                      as Color,
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                              fontStyle: FontStyle.normal,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          textAlign: TextAlign.center,
                          textDirection: TextDirection.ltr,
                        ),
                      )),
                ),
                GestureDetector(
                  onTap: () async {
                    await Navigator.push<void>(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PageDisclaimer(),
                      ),
                    );
                  },
                  child: Container(
                      width: double.maxFinite,
                      height: 48,
                      decoration: BoxDecoration(
                        color: context.watch<ThemeCubit>().state
                            ? TetaThemes.lightTheme['Text / Primary'] as Color
                            : TetaThemes.darkTheme['Text / Primary'] as Color,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30),
                          bottomRight: Radius.circular(30),
                          bottomLeft: Radius.circular(30),
                        ),
                        border: null,
                      ),
                      child: Center(
                        child: Text(
                          '''Disclaimer''',
                          style: GoogleFonts.poppins(
                            textStyle: TextStyle(
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes
                                          .lightTheme['Background / Primary']
                                      as Color
                                  : TetaThemes.darkTheme['Background / Primary']
                                      as Color,
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                              fontStyle: FontStyle.normal,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          textAlign: TextAlign.center,
                          textDirection: TextDirection.ltr,
                        ),
                      )),
                ),
              ],
            ),
          ),
        ),
      ),
      backgroundColor: const Color(0xFF000000),
      body: Stack(
        children: [
          Container(
            width: double.maxFinite,
            height: 100.h,
            decoration: BoxDecoration(
              color: context.watch<ThemeCubit>().state
                  ? TetaThemes.lightTheme['Background / Primary'] as Color
                  : TetaThemes.darkTheme['Background / Primary'] as Color,
            ),
            child: NotificationListener<ScrollEndNotification>(
              onNotification: (final scrollEnd) {
                final metrics = scrollEnd.metrics;
                if (metrics.atEdge) {
                  final isTop = metrics.pixels == 0;
                  if (isTop) {
                  } else {}
                }
                return true;
              },
              child: ListView(
                reverse: false,
                primary: true,
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  SafeArea(
                    left: false,
                    top: false,
                    right: false,
                    bottom: false,
                    child: SizedBox(
                      width: double.maxFinite,
                      height: 6.h,
                      child: Padding(
                        padding: const EdgeInsets.only(
                          left: 24,
                          top: 24,
                          right: 24,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              MdiIcons.fromString('keyboard-backspace'),
                              size: 40,
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes.lightTheme['Text / Primary']
                                      as Color
                                  : TetaThemes.darkTheme['Text / Primary']
                                      as Color,
                            ),
                            Icon(
                              MdiIcons.fromString('menu'),
                              size: 40,
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes.lightTheme['Text / Primary']
                                      as Color
                                  : TetaThemes.darkTheme['Text / Primary']
                                      as Color,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: double.maxFinite,
                    height: 2.h,
                    child: Text(r'''''',
                        style: GoogleFonts.poppins(
                          textStyle: TextStyle(
                            color: context.watch<ThemeCubit>().state
                                ? TetaThemes.lightTheme['Background / Primary']
                                    as Color
                                : TetaThemes.darkTheme['Background / Primary']
                                    as Color,
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            fontStyle: FontStyle.normal,
                            decoration: TextDecoration.none,
                          ),
                        ),
                        textAlign: TextAlign.left,
                        textDirection: TextDirection.ltr,
                        maxLines: 1),
                  ),
                  SizedBox(
                    width: double.maxFinite,
                    height: 1.h,
                    child: Padding(
                      padding: const EdgeInsets.only(
                        left: 24,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(r'''Welcome Back''',
                              style: GoogleFonts.poppins(
                                textStyle: TextStyle(
                                  color: context.watch<ThemeCubit>().state
                                      ? TetaThemes.lightTheme['Text / Primary']
                                          as Color
                                      : TetaThemes.darkTheme['Text / Primary']
                                          as Color,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 16,
                                  fontStyle: FontStyle.normal,
                                  decoration: TextDecoration.none,
                                ),
                              ),
                              textAlign: TextAlign.left,
                              textDirection: TextDirection.ltr,
                              maxLines: 1),
                          Text(r'''Todays Video''',
                              style: GoogleFonts.poppins(
                                textStyle: TextStyle(
                                  color: context.watch<ThemeCubit>().state
                                      ? TetaThemes.lightTheme['Text / Primary']
                                          as Color
                                      : TetaThemes.darkTheme['Text / Primary']
                                          as Color,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  fontStyle: FontStyle.normal,
                                  decoration: TextDecoration.none,
                                ),
                              ),
                              textAlign: TextAlign.left,
                              textDirection: TextDirection.ltr,
                              maxLines: 1),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    width: double.maxFinite,
                    height: 45,
                    child: Text(r'''''',
                        style: GoogleFonts.poppins(
                          textStyle: TextStyle(
                            color: context.watch<ThemeCubit>().state
                                ? TetaThemes.lightTheme['Text / Primary']
                                    as Color
                                : TetaThemes.darkTheme['Text / Primary']
                                    as Color,
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            fontStyle: FontStyle.normal,
                            decoration: TextDecoration.none,
                          ),
                        ),
                        textAlign: TextAlign.left,
                        textDirection: TextDirection.ltr,
                        maxLines: 1),
                  ),
                  SizedBox(
                    width: double.maxFinite,
                    height: 40.h,
                    child: Padding(
                      padding: const EdgeInsets.only(
                        left: 24,
                        top: 16,
                        right: 24,
                      ),
                      child: TetaFutureBuilder(
                          future: TetaCMS.instance.client.getCollection(
                            '''6358c5d5c005913d9fb4b7b5''',
                            filters: [],
                            limit: 20,
                            page: 0,
                          ),
                          builder: (context, snapshot) {
                            if (!snapshot.hasData) {
                              return const Center(
                                child: CircularProgressIndicator(),
                              );
                            }
                            final list = snapshot.data as List<dynamic>?;
                            datasets['Cms fetch'] = list ?? const <dynamic>[];

                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Image.network(
                                  '''${(this.datasets['Cms fetch']?[index]?['Cover']?.toString() ?? '')}''',
                                  width: double.maxFinite,
                                  height: 150,
                                  fit: BoxFit.fill,
                                ),
                                Container(
                                  margin: const EdgeInsets.only(
                                    right: 16,
                                    bottom: 8,
                                  ),
                                  padding: const EdgeInsets.only(
                                    top: 2,
                                    right: 8,
                                    bottom: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: context.watch<ThemeCubit>().state
                                        ? TetaThemes.lightTheme[
                                            'Background / Primary'] as Color
                                        : TetaThemes.darkTheme[
                                            'Background / Primary'] as Color,
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(4),
                                      topRight: Radius.circular(4),
                                      bottomRight: Radius.circular(4),
                                      bottomLeft: Radius.circular(4),
                                    ),
                                  ),
                                  child: Text(
                                      '''${(this.datasets['Cms fetch']?[index]?['Category']?.toString() ?? '')}''',
                                      style: GoogleFonts.poppins(
                                        textStyle: TextStyle(
                                          color:
                                              Color(0xFFFFFFFF).withOpacity(1),
                                          fontWeight: FontWeight.w700,
                                          fontSize: 14,
                                          fontStyle: FontStyle.normal,
                                          decoration: TextDecoration.none,
                                        ),
                                      ),
                                      textAlign: TextAlign.center,
                                      textDirection: TextDirection.ltr,
                                      maxLines: 1),
                                ),
                                Text(
                                    '''${(this.datasets['Cms fetch']?[index]?['Title']?.toString() ?? '')}''',
                                    style: GoogleFonts.poppins(
                                      textStyle: TextStyle(
                                        color: Color(0xFFFFFFFF).withOpacity(1),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 20,
                                        fontStyle: FontStyle.normal,
                                        decoration: TextDecoration.none,
                                      ),
                                    ),
                                    textAlign: TextAlign.left,
                                    textDirection: TextDirection.ltr,
                                    maxLines: 1),
                                Padding(
                                  padding: const EdgeInsets.only(
                                    top: 4,
                                  ),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                          '''${(this.datasets['Cms fetch']?[index]?['created_at']?.toString() ?? '')}''',
                                          style: GoogleFonts.poppins(
                                            textStyle: TextStyle(
                                              color: Color(0xFFFFFFFF)
                                                  .withOpacity(1),
                                              fontWeight: FontWeight.w200,
                                              fontSize: 16,
                                              fontStyle: FontStyle.normal,
                                              decoration: TextDecoration.none,
                                            ),
                                          ),
                                          textAlign: TextAlign.left,
                                          textDirection: TextDirection.ltr,
                                          maxLines: 1),
                                    ],
                                  ),
                                ),
                              ],
                            );
                          }),
                    ),
                  ),
                  SizedBox(
                    width: double.maxFinite,
                    height: 10,
                    child: Text(r'''''',
                        style: GoogleFonts.poppins(
                          textStyle: TextStyle(
                            color: context.watch<ThemeCubit>().state
                                ? TetaThemes.lightTheme['Background / Primary']
                                    as Color
                                : TetaThemes.darkTheme['Background / Primary']
                                    as Color,
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            fontStyle: FontStyle.normal,
                            decoration: TextDecoration.none,
                          ),
                        ),
                        textAlign: TextAlign.left,
                        textDirection: TextDirection.ltr,
                        maxLines: 1),
                  ),
                  SizedBox(
                    width: double.maxFinite,
                    height: 25,
                    child: Container(
                      margin: const EdgeInsets.only(
                        left: 24,
                      ),
                      width: double.maxFinite,
                      height: double.maxFinite,
                      decoration: BoxDecoration(
                        color: context.watch<ThemeCubit>().state
                            ? TetaThemes.lightTheme['Background / Primary']
                                as Color
                            : TetaThemes.darkTheme['Background / Primary']
                                as Color,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                          bottomRight: Radius.circular(20),
                          bottomLeft: Radius.circular(20),
                        ),
                      ),
                      child: Text(r'''Discover...''',
                          style: GoogleFonts.poppins(
                            textStyle: TextStyle(
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes.lightTheme['Text / Primary']
                                      as Color
                                  : TetaThemes.darkTheme['Text / Primary']
                                      as Color,
                              fontWeight: FontWeight.w700,
                              fontSize: 20,
                              fontStyle: FontStyle.normal,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          textAlign: TextAlign.left,
                          textDirection: TextDirection.ltr,
                          maxLines: 1),
                    ),
                  ),
                  SizedBox(
                    width: double.maxFinite,
                    height: 15,
                    child: Text(r'''''',
                        style: GoogleFonts.poppins(
                          textStyle: TextStyle(
                            color: Color(0xFFFFFFFF).withOpacity(1),
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            fontStyle: FontStyle.normal,
                            decoration: TextDecoration.none,
                          ),
                        ),
                        textAlign: TextAlign.left,
                        textDirection: TextDirection.ltr,
                        maxLines: 1),
                  ),
                  SizedBox(
                    width: double.maxFinite,
                    height: 28.h,
                    child: NotificationListener<ScrollEndNotification>(
                      onNotification: (final scrollEnd) {
                        final metrics = scrollEnd.metrics;
                        if (metrics.atEdge) {
                          final isTop = metrics.pixels == 0;
                          if (isTop) {
                          } else {}
                        }
                        return true;
                      },
                      child: ListView(
                        reverse: false,
                        primary: true,
                        physics: const AlwaysScrollableScrollPhysics(),
                        scrollDirection: Axis.horizontal,
                        children: [
                          Container(
                            margin: const EdgeInsets.only(
                              left: 24,
                              top: 6,
                            ),
                            width: 180,
                            height: double.maxFinite,
                            decoration: BoxDecoration(
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes
                                          .lightTheme['Background / Details']
                                      as Color
                                  : TetaThemes.darkTheme['Background / Details']
                                      as Color,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                                bottomRight: Radius.circular(20),
                                bottomLeft: Radius.circular(20),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Image.network(
                                  r'''https://ujwtjucjmyzlktgfrara.supabase.co/storage/v1/object/public/videoimages/Video%20images/1qdNVO2RK4g.jpg''',
                                  width: double.maxFinite,
                                  height: 140,
                                  fit: BoxFit.cover,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                    left: 10,
                                    top: 4,
                                  ),
                                  child: Text(r'''W.W.E RAW''',
                                      style: GoogleFonts.poppins(
                                        textStyle: TextStyle(
                                          color: context
                                                  .watch<ThemeCubit>()
                                                  .state
                                              ? TetaThemes.lightTheme[
                                                  'Text / Primary'] as Color
                                              : TetaThemes.darkTheme[
                                                  'Text / Primary'] as Color,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 14,
                                          fontStyle: FontStyle.normal,
                                          decoration: TextDecoration.none,
                                        ),
                                      ),
                                      textAlign: TextAlign.left,
                                      textDirection: TextDirection.ltr,
                                      maxLines: 5),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.only(
                              left: 24,
                              top: 6,
                            ),
                            width: 180,
                            height: 200,
                            decoration: BoxDecoration(
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes
                                          .lightTheme['Background / Details']
                                      as Color
                                  : TetaThemes.darkTheme['Background / Details']
                                      as Color,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                                bottomRight: Radius.circular(20),
                                bottomLeft: Radius.circular(20),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20),
                                    bottomRight: Radius.circular(20),
                                    bottomLeft: Radius.circular(20),
                                  ),
                                  child: Image.network(
                                    r'''https://ujwtjucjmyzlktgfrara.supabase.co/storage/v1/object/public/videoimages/Video%20images/no4NXvXb79M.jpg''',
                                    width: double.maxFinite,
                                    height: 140,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Text(r'''Cheer Up''',
                                    style: GoogleFonts.poppins(
                                      textStyle: TextStyle(
                                        color: context.watch<ThemeCubit>().state
                                            ? TetaThemes.lightTheme[
                                                'Text / Primary'] as Color
                                            : TetaThemes
                                                    .darkTheme['Text / Primary']
                                                as Color,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14,
                                        fontStyle: FontStyle.normal,
                                        decoration: TextDecoration.none,
                                      ),
                                    ),
                                    textAlign: TextAlign.left,
                                    textDirection: TextDirection.ltr,
                                    maxLines: 5),
                              ],
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.only(
                              left: 20,
                              top: 6,
                            ),
                            width: 180,
                            height: double.maxFinite,
                            decoration: BoxDecoration(
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes
                                          .lightTheme['Background / Details']
                                      as Color
                                  : TetaThemes.darkTheme['Background / Details']
                                      as Color,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                                bottomRight: Radius.circular(20),
                                bottomLeft: Radius.circular(20),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20),
                                    bottomRight: Radius.circular(20),
                                    bottomLeft: Radius.circular(20),
                                  ),
                                  child: Image.network(
                                    r'''https://ujwtjucjmyzlktgfrara.supabase.co/storage/v1/object/public/bookimages/Images/970024442b4e4275ab78c85b820fc0af.jpeg''',
                                    width: double.maxFinite,
                                    height: 140,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Text(r'''Villian please go easy on me''',
                                    style: GoogleFonts.poppins(
                                      textStyle: TextStyle(
                                        color: context.watch<ThemeCubit>().state
                                            ? TetaThemes.lightTheme[
                                                'Text / Primary'] as Color
                                            : TetaThemes
                                                    .darkTheme['Text / Primary']
                                                as Color,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14,
                                        fontStyle: FontStyle.normal,
                                        decoration: TextDecoration.none,
                                      ),
                                    ),
                                    textAlign: TextAlign.left,
                                    textDirection: TextDirection.ltr,
                                    maxLines: 5),
                              ],
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.only(
                              left: 20,
                              top: 6,
                            ),
                            width: 180,
                            height: double.maxFinite,
                            decoration: BoxDecoration(
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes
                                          .lightTheme['Background / Details']
                                      as Color
                                  : TetaThemes.darkTheme['Background / Details']
                                      as Color,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                                bottomRight: Radius.circular(20),
                                bottomLeft: Radius.circular(20),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20),
                                    bottomRight: Radius.circular(20),
                                    bottomLeft: Radius.circular(20),
                                  ),
                                  child: Image.network(
                                    r'''https://ujwtjucjmyzlktgfrara.supabase.co/storage/v1/object/public/videoimages/Video%20images/Gem7Q8wEKYx.jpg''',
                                    width: double.maxFinite,
                                    height: 140,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Text(r'''All American; Homecoming''',
                                    style: GoogleFonts.poppins(
                                      textStyle: TextStyle(
                                        color: context.watch<ThemeCubit>().state
                                            ? TetaThemes.lightTheme[
                                                'Text / Primary'] as Color
                                            : TetaThemes
                                                    .darkTheme['Text / Primary']
                                                as Color,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14,
                                        fontStyle: FontStyle.normal,
                                        decoration: TextDecoration.none,
                                      ),
                                    ),
                                    textAlign: TextAlign.left,
                                    textDirection: TextDirection.ltr,
                                    maxLines: 5),
                              ],
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.only(
                              left: 20,
                              top: 6,
                            ),
                            width: 180,
                            height: double.maxFinite,
                            decoration: BoxDecoration(
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes
                                          .lightTheme['Background / Details']
                                      as Color
                                  : TetaThemes.darkTheme['Background / Details']
                                      as Color,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                                bottomRight: Radius.circular(20),
                                bottomLeft: Radius.circular(20),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20),
                                    bottomRight: Radius.circular(20),
                                    bottomLeft: Radius.circular(20),
                                  ),
                                  child: Image.network(
                                    r'''https://ujwtjucjmyzlktgfrara.supabase.co/storage/v1/object/public/videoimages/Video%20images/G4E7z9vmKb6.jpg''',
                                    width: double.maxFinite,
                                    height: 140,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Text(r'''Guardian Of Time''',
                                    style: GoogleFonts.poppins(
                                      textStyle: TextStyle(
                                        color: context.watch<ThemeCubit>().state
                                            ? TetaThemes.lightTheme[
                                                'Text / Primary'] as Color
                                            : TetaThemes
                                                    .darkTheme['Text / Primary']
                                                as Color,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14,
                                        fontStyle: FontStyle.normal,
                                        decoration: TextDecoration.none,
                                      ),
                                    ),
                                    textAlign: TextAlign.left,
                                    textDirection: TextDirection.ltr,
                                    maxLines: 1),
                              ],
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.only(
                              left: 20,
                              top: 6,
                            ),
                            width: 180,
                            height: double.maxFinite,
                            decoration: BoxDecoration(
                              color: context.watch<ThemeCubit>().state
                                  ? TetaThemes
                                          .lightTheme['Background / Details']
                                      as Color
                                  : TetaThemes.darkTheme['Background / Details']
                                      as Color,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                                bottomRight: Radius.circular(20),
                                bottomLeft: Radius.circular(20),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20),
                                    bottomRight: Radius.circular(20),
                                    bottomLeft: Radius.circular(20),
                                  ),
                                  child: Image.network(
                                    r'''0''',
                                    width: double.maxFinite,
                                    height: 140,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Text(r'''Blade of the 47 Ronin''',
                                    style: GoogleFonts.poppins(
                                      textStyle: TextStyle(
                                        color: context.watch<ThemeCubit>().state
                                            ? TetaThemes.lightTheme[
                                                'Text / Primary'] as Color
                                            : TetaThemes
                                                    .darkTheme['Text / Primary']
                                                as Color,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14,
                                        fontStyle: FontStyle.normal,
                                        decoration: TextDecoration.none,
                                      ),
                                    ),
                                    textAlign: TextAlign.left,
                                    textDirection: TextDirection.ltr,
                                    maxLines: 1),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 150,
                            height: 20,
                            child: Container(
                              margin: const EdgeInsets.only(
                                left: 24,
                              ),
                              width: 60,
                              height: 10,
                              decoration: BoxDecoration(
                                color: context.watch<ThemeCubit>().state
                                    ? TetaThemes.lightTheme['Text / Primary']
                                        as Color
                                    : TetaThemes.darkTheme['Text / Primary']
                                        as Color,
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                  topRight: Radius.circular(20),
                                  bottomRight: Radius.circular(20),
                                  bottomLeft: Radius.circular(20),
                                ),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    MdiIcons.fromString(
                                        'book-plus-multiple-outline'),
                                    size: 24,
                                    color: context.watch<ThemeCubit>().state
                                        ? TetaThemes.lightTheme[
                                            'Background / Primary'] as Color
                                        : TetaThemes.darkTheme[
                                            'Background / Primary'] as Color,
                                  ),
                                  Text(r'''Our Library''',
                                      style: GoogleFonts.poppins(
                                        textStyle: TextStyle(
                                          color: context
                                                  .watch<ThemeCubit>()
                                                  .state
                                              ? TetaThemes.lightTheme[
                                                      'Background / Primary']
                                                  as Color
                                              : TetaThemes.darkTheme[
                                                      'Background / Primary']
                                                  as Color,
                                          fontWeight: FontWeight.w800,
                                          fontSize: 20,
                                          fontStyle: FontStyle.normal,
                                          decoration: TextDecoration.none,
                                        ),
                                      ),
                                      textAlign: TextAlign.left,
                                      textDirection: TextDirection.ltr,
                                      maxLines: 2),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
