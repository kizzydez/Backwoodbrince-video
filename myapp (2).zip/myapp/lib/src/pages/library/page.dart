import 'dart:async';
import 'package:myapp/src/teta_files/imports.dart';
import 'package:myapp/constants.dart' as constantz;
import 'package:myapp/auth/auth_state.dart';

import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:bouncing_widget/bouncing_widget.dart';
import 'package:webviewx/webviewx.dart';

class PageLibrary extends StatefulWidget {
  const PageLibrary({
    Key? key,
  }) : super(key: key);

  @override
  _StateLibrary createState() => _StateLibrary();
}

class _StateLibrary extends State<PageLibrary> {
  WebViewXController? websii = null;

  var datasets = <String, dynamic>{};
  int index = 0;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    TetaCMS.instance.analytics.insertEvent(
      TetaAnalyticsType.usage,
      'App usage: view page',
      <String, dynamic>{
        'name': "Library",
      },
      isUserIdPreferableIfExists: true,
    );

    unawaited(
      Future.delayed(
        Duration.zero,
        () async {},
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomInset: true,
      backgroundColor: const Color(0xFF000000),
      body: Stack(
        children: [
          Container(
            margin: const EdgeInsets.only(
              left: 10,
            ),
            width: double.maxFinite,
            height: double.maxFinite,
            decoration: BoxDecoration(
              color: context.watch<ThemeCubit>().state
                  ? TetaThemes.lightTheme['Background / Primary'] as Color
                  : TetaThemes.darkTheme['Background / Primary'] as Color,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SafeArea(
                  left: false,
                  top: true,
                  right: false,
                  bottom: false,
                  child: Container(
                    margin: const EdgeInsets.only(
                      left: 10,
                      bottom: 5,
                    ),
                    width: double.maxFinite,
                    height: 50,
                    decoration: BoxDecoration(
                      color: context.watch<ThemeCubit>().state
                          ? TetaThemes.lightTheme['Background / Primary']
                              as Color
                          : TetaThemes.darkTheme['Background / Primary']
                              as Color,
                    ),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                            right: 65,
                          ),
                          child: Icon(
                            MdiIcons.fromString('keyboard-backspace'),
                            size: 40,
                            color: context.watch<ThemeCubit>().state
                                ? TetaThemes.lightTheme['Text / Primary']
                                    as Color
                                : TetaThemes.darkTheme['Text / Primary']
                                    as Color,
                          ),
                        ),
                        Icon(
                          MdiIcons.fromString('movie-open-play'),
                          size: 25,
                          color: context.watch<ThemeCubit>().state
                              ? TetaThemes.lightTheme['Text / Primary'] as Color
                              : TetaThemes.darkTheme['Text / Primary'] as Color,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                            left: 10,
                          ),
                          child: Text(r'''Movie Link''',
                              style: GoogleFonts.poppins(
                                textStyle: TextStyle(
                                  color: context.watch<ThemeCubit>().state
                                      ? TetaThemes.lightTheme['Text / Primary']
                                          as Color
                                      : TetaThemes.darkTheme['Text / Primary']
                                          as Color,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 25,
                                  fontStyle: FontStyle.normal,
                                  decoration: TextDecoration.none,
                                ),
                              ),
                              textAlign: TextAlign.left,
                              textDirection: TextDirection.ltr,
                              maxLines: 1),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  width: double.maxFinite,
                  height: double.maxFinite,
                  child: NotificationListener<ScrollEndNotification>(
                    onNotification: (final scrollEnd) {
                      final metrics = scrollEnd.metrics;
                      if (metrics.atEdge) {
                        final isTop = metrics.pixels == 0;
                        if (isTop) {
                        } else {}
                      }
                      return true;
                    },
                    child: ListView(
                      reverse: false,
                      primary: true,
                      physics: const AlwaysScrollableScrollPhysics(),
                      children: [
                        Container(
                          width: double.maxFinite,
                          decoration: BoxDecoration(
                            color: context.watch<ThemeCubit>().state
                                ? TetaThemes.lightTheme['Text / Primary']
                                    as Color
                                : TetaThemes.darkTheme['Text / Primary']
                                    as Color,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Image.network(
                                r'''https://ujwtjucjmyzlktgfrara.supabase.co/storage/v1/object/public/videoimages/Video%20images/cropped-cropped-cropped-LogoMakr_62nXwA-1.png''',
                                width: double.maxFinite,
                                height: 150,
                                fit: BoxFit.contain,
                              ),
                              Text(r'''Korean Movies''',
                                  style: GoogleFonts.poppins(
                                    textStyle: TextStyle(
                                      color: context.watch<ThemeCubit>().state
                                          ? TetaThemes.lightTheme[
                                              'Background / Primary'] as Color
                                          : TetaThemes.darkTheme[
                                              'Background / Primary'] as Color,
                                      fontWeight: FontWeight.w400,
                                      fontSize: 16,
                                      fontStyle: FontStyle.normal,
                                      decoration: TextDecoration.none,
                                    ),
                                  ),
                                  textAlign: TextAlign.center,
                                  textDirection: TextDirection.ltr,
                                  maxLines: 1),
                            ],
                          ),
                        ),
                        Container(
                          width: double.maxFinite,
                          height: 130,
                          decoration: BoxDecoration(
                            color: context.watch<ThemeCubit>().state
                                ? TetaThemes.lightTheme['Background / Primary']
                                    as Color
                                : TetaThemes.darkTheme['Background / Primary']
                                    as Color,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Image.network(
                                r'''https://ujwtjucjmyzlktgfrara.supabase.co/storage/v1/object/public/videoimages/Video%20images/logo.webp''',
                                width: double.maxFinite,
                                fit: BoxFit.contain,
                              ),
                              Text(r'''Anime''',
                                  style: GoogleFonts.poppins(
                                    textStyle: TextStyle(
                                      color: context.watch<ThemeCubit>().state
                                          ? TetaThemes
                                                  .lightTheme['Text / Primary']
                                              as Color
                                          : TetaThemes
                                                  .darkTheme['Text / Primary']
                                              as Color,
                                      fontWeight: FontWeight.w400,
                                      fontSize: 16,
                                      fontStyle: FontStyle.normal,
                                      decoration: TextDecoration.none,
                                    ),
                                  ),
                                  textAlign: TextAlign.center,
                                  textDirection: TextDirection.ltr,
                                  maxLines: 1),
                            ],
                          ),
                        ),
                        Container(
                          width: double.maxFinite,
                          decoration: BoxDecoration(
                            color: context.watch<ThemeCubit>().state
                                ? TetaThemes.lightTheme['Background / Primary']
                                    as Color
                                : TetaThemes.darkTheme['Background / Primary']
                                    as Color,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Image.network(
                                r'''https://ujwtjucjmyzlktgfrara.supabase.co/storage/v1/object/public/videoimages/Video%20images/logo.silver.png''',
                                width: double.maxFinite,
                                height: 130,
                                fit: BoxFit.contain,
                              ),
                              Text(r'''Bollywood''',
                                  style: GoogleFonts.poppins(
                                    textStyle: TextStyle(
                                      color: context.watch<ThemeCubit>().state
                                          ? TetaThemes
                                                  .lightTheme['Text / Primary']
                                              as Color
                                          : TetaThemes
                                                  .darkTheme['Text / Primary']
                                              as Color,
                                      fontWeight: FontWeight.w400,
                                      fontSize: 16,
                                      fontStyle: FontStyle.normal,
                                      decoration: TextDecoration.none,
                                    ),
                                  ),
                                  textAlign: TextAlign.center,
                                  textDirection: TextDirection.ltr,
                                  maxLines: 1),
                            ],
                          ),
                        ),
                        Container(
                          width: double.maxFinite,
                          decoration: BoxDecoration(
                            color: context.watch<ThemeCubit>().state
                                ? TetaThemes.lightTheme['Text / Primary']
                                    as Color
                                : TetaThemes.darkTheme['Text / Primary']
                                    as Color,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Image.network(
                                r'''https://ujwtjucjmyzlktgfrara.supabase.co/storage/v1/object/public/videoimages/Video%20images/c49337aa9c92d6fbf56b6b5830c6849c.png''',
                                width: double.maxFinite,
                                height: 150,
                                fit: BoxFit.contain,
                              ),
                              Text(r'''Hollywood''',
                                  style: GoogleFonts.poppins(
                                    textStyle: TextStyle(
                                      color: context.watch<ThemeCubit>().state
                                          ? TetaThemes.lightTheme[
                                              'Background / Primary'] as Color
                                          : TetaThemes.darkTheme[
                                              'Background / Primary'] as Color,
                                      fontWeight: FontWeight.w400,
                                      fontSize: 16,
                                      fontStyle: FontStyle.normal,
                                      decoration: TextDecoration.none,
                                    ),
                                  ),
                                  textAlign: TextAlign.center,
                                  textDirection: TextDirection.ltr,
                                  maxLines: 1),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
